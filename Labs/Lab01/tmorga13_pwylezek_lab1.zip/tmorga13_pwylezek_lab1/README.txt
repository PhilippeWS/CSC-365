Navigate to the directory containing the class files.

Compile with:
    javac schoolsearch.java
Run with:
    java schoolsearch